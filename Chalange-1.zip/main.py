num=int(input("Enter a number:"))
factorial=1
if num < 0:
     print("Factorial not exits for negative number")
elif num==0:
     print(" The factorial of 0 is 1")
else:
  for i in range(1, num+1):
       factorial  =factorial*i
  print("The fact of",num," is", factorial)